print("===========================")
print("Welcome here")
print("My first post!")
print("===========================")

username = input("Enter Username: ")
age = int(input("Enter Age: "))
category = input("Enter Content Category: ")
bio = input("Blogger info: ")
followers = input("Followers Count: ")

print("\nInstagram Profile")
print("=====================")
print("Username:", username)
print("Age:", age)
print("Category:", category)

if age>40 and category == "fun":
    print("You are old what is fun for you??")



print("\nInstagram Profile")
print("=====================")
print("Username:", username)
print("Age:", age)
print("Category:", category)




followers += 50
print("Day 1:", followers)

followers += 20
print("Day 2:", followers)

followers -= 10
print("Day 3:", followers)


print("Username:", username)
print("Bio:", bio)
print("Followers:", followers)



